import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { CommonService } from '../../service/common.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
 userList: any = [];

  constructor(
    private commonService: CommonService,
    private _http: HttpClient,
    private _fb: FormBuilder
  ) { }

  deleteUser(id: number) {
    if (confirm("Are you Sure?")) {
      this.commonService.deleteUser(id).subscribe(() => {
        this.getAll();
      })
    }
  }

  ngOnInit(): void {
    this.getAll()
  }
  
  getAll() {
    this.commonService.getAll().subscribe((response) => {
      this.userList = response;
      console.log(this.userList.data);
      
    })
  }


}




