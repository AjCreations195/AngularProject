import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  url: string = "https://v2-dev-api.isorobot.io/api/v1/organization-policies/"

  authToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImRlNWY1ZTk3Y2UxNWIzZTQwOTE2MGEzMmNhMjFkNTI1Yjc4M2JiZjFhYWM3NmIxZDI2NmMzMDBmNjNiMDU4MTdiN2E5M2VhMWRmNTcyZWI3In0.eyJhdWQiOiIxIiwianRpIjoiZGU1ZjVlOTdjZTE1YjNlNDA5MTYwYTMyY2EyMWQ1MjViNzgzYmJmMWFhYzc2YjFkMjY2YzMwMGY2M2IwNTgxN2I3YTkzZWExZGY1NzJlYjciLCJpYXQiOjE2Mzk0OTM2NjEsIm5iZiI6MTYzOTQ5MzY2MSwiZXhwIjoxNjcxMDI5NjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.pXOfKO7k4aeEaONGqHkn6AceJGQNaELLHmNoanq8IR54p8w8FwQuOxZzflK9F1QML_6wnJOso-B0VDyGubAdNsIW9l4fj1XHdZMs0sEKh9Tkt05KCK3mYoiDxwy8RyZ9dcAzRT_Vc09BkIw6OTi3yXhB06OMWPWiqAuD4-dRvea1KCVtI8Ky8947G03Pv1tiRpIwOY0bmBjiJmps04bw1HKKVtck7gL1_D1eu7tIeLb-4uj8G5ldh98RGFvaYuDtGBcF9pWClvf7qLix_W589zRedTBLVAr-VMW7JQuv-pFORFMAwWkJsNAnD8q2CUjFGeVfjZkzvxrHfI0TRy6BSD2ssocIoEOdZzMSuHn84f76enloHfjRk0BVuzubMp6zeN6OGTHDFkR6yvfjTg5KuvovVYegEg20GNTEcQDO5-CdNWc8943hAIiqMLzXfhizkRVXsbJou69tCnaB4IVOQH6okV11BhRD7r3E8WA9vq-i9wf9guzTOA1kf1OKYGlfJzvzWS6zDR8T_j7B0poBmzH4O6j16WITrDLiCndGmLUpXZtzMzF5B_aQAKUws6mZT1g_UabxtKUZ0r58CEiNk990TEzDbYFAVIpfFjxF9USRHNF4ISXKtdVbFQHQsvfGst_3-Pqnm1RRW_PivRCNq9p8sTH7XN3xYKTSVIDBLGE"
  auth = `Bearer ${this.authToken}`;
  Headers = new HttpHeaders();
  Header=this.Headers.set('Authorization', this.auth)

  constructor(private _http: HttpClient) {
  }


  getAll() {

    return this._http.get("https://v2-dev-api.isorobot.io/api/v1/organization-policies",{ headers: this.Header })
  }
  AddUser(id: number, addUserForm: any) {
    return this._http.post("https://v2-dev-api.isorobot.io/api/v1/organization-policies", addUserForm.value,{ headers: this.Header })

  }
  deleteUser(id: number) {
    return this._http.delete(this.url + id, { headers: this.Header })
  }
  getCurrentData(id: number) {
    return this._http.get(this.url + id, { headers: this.Header })
  }
  editUser(id: number, data: any) {
    return this._http.put(this.url + id, data,{ headers: this.Header })
  }
}

