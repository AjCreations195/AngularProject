import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  URL = "http://localhost:3000/users/";
  addUserForm = new FormGroup({
    id: new FormControl(),
    name: new FormControl(),
    email: new FormControl(),
    contact: new FormControl(),
    is_active: new FormControl()
  });
  isSubmitted: boolean = false;
  constructor(public router: Router,
    private CommonService: CommonService,
    private _fb: FormBuilder,
    private _http: HttpClient) { }
  ngOnInit(): void {
    this.addUserForm = this._fb.group({
      id: [0],
      name: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      contact: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      is_active: [1]
    });
  }
  get _fc() {
    return this.addUserForm.controls;
  }




  save() {
    this.isSubmitted = true;
    if (this.addUserForm.invalid) {
      return;
    } else {
      let id = this.addUserForm.controls['id'].value;
      if (!id) {
        this._http.post(this.URL, this.addUserForm.value).subscribe(() => {
          alert('Created Successfully');
          this.router.navigate(['/user-details'])
        })
      }
    }
  }
  reset() {
    this.addUserForm.reset();
    this.addUserForm.controls['is_active'].setValue(1);
    this.isSubmitted = false;
  }

}
