import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(private _http: HttpClient) { }
  url: string = "http://localhost:3000/users/";

  deleteUser(id: number) {
    return this._http.delete(this.url + id)
  }
  getCurrentData(id: number) {
    return this._http.get(this.url + id)
  }
  editUser(id: number, data: any) {
    return this._http.put(this.url + id, data)
  }

}