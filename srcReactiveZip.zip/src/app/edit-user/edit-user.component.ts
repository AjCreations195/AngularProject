import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router'
import { CommonService } from '../common.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})

export class EditUserComponent implements OnInit {
  URL = "http://localhost:3000/users/";
  alert: boolean = false;
  editUserForm = new FormGroup({
    id: new FormControl(),
    name: new FormControl(),
    email: new FormControl(),
    contact: new FormControl()
  });
  public userList: any = [];
  isSubmitted: boolean = false;
  id: number = 0;
  constructor(public router: Router,
    private CommonService: CommonService,
    private _fb: FormBuilder,
    private _http: HttpClient,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.CommonService.getCurrentData(this.id).subscribe((response: any) => {

      this.editUserForm = new FormGroup({
        id: new FormControl(response['id']),
        name: new FormControl(response['name'], [Validators.required, Validators.minLength(5)]),
        email: new FormControl(response['email'], [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
        contact: new FormControl(response['contact'], [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")])
      });

    })
  }

  editUser() {
    this.isSubmitted = true;
    if (this.editUserForm.invalid) {
      return;
    } else {
      this.CommonService.editUser(this.route.snapshot.params['id'], this.editUserForm.value)
        .subscribe((response) => {
          alert('Updated Successfully');
          this.router.navigate(['/user-details'])
        })
    }
  }
  // fetching form control values
  get _fc() {
    return this.editUserForm.controls;
  }

}