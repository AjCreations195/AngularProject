import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { CommonService } from '../common.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css'],
  providers: [CommonService]
})
export class UserDetailsComponent implements OnInit {

  URL = "http://localhost:3000/users";
  userList: any = [];
  constructor(
    private commonService: CommonService,
    private _http: HttpClient,
    private _fb: FormBuilder
  ) { }

  deleteUser(id: number) {
    if (confirm("Are you Sure?")) {
      this.commonService.deleteUser(id).subscribe(() => {
        this.getAll();
      })
    }
  }

  ngOnInit(): void {
    this.getAll()

  }

  getAll() {
    this._http.get(this.URL).subscribe((response) => {
      this.userList = response;
    })
  }

}




