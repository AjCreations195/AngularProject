import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  constructor(public router: Router, private CommonService: CommonService, private _http: HttpClient) { }
  UserObj: any = Object;
  confirmationString: string = "New Product has been added";
  isAdded: boolean = false;
  addUser(user: any) {
    this.UserObj = {
      "name": user.name,
      "email": user.email,
      "contact": user.contact,
      "id": user.id
    }
    this._http.post("http://localhost:3000/users", this.UserObj).subscribe((response) => {
      this.isAdded = true;
      this.router.navigate(['/user-details'])

    })
  }


  ngOnInit(): void {

  }

}
