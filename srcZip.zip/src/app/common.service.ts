import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  headers = new HttpHeaders().set('Content-type', 'application/json').set('Accept', 'application/json');

  constructor(private _http: HttpClient) { }
  url: string = "http://localhost:3000/users";

  deleteUser(id: number) {
    return this._http.delete("http://localhost:3000/users/" + id)
  }


}