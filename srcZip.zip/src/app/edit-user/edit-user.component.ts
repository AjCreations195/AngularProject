import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms'
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router'
import { CommonService } from '../common.service';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  alert: boolean = false;
  id: number = 0;
  data: any = [];
  users: Array<any> = [];
  userObj: object = {};
  isEdited: boolean = false;
  UserObj = {
    "name": "",
    "email": "",
    "contact": "",
    "id": ""
  }
  confirmationString: string = "The product has been updated";


  constructor(private CommonService: CommonService, private route: ActivatedRoute, private router: Router, private _http: HttpClient) 
  { }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];
    this._http.get("http://localhost:3000/users").subscribe((response: any) => {
      for (let i of response) {
        this.users.push(i);
      }
      for (var i = 0; i < this.users.length; i++) {
        if (this.users[i].id == this.id) {
          this.data = this.users[i];
          break;
        }

      }
    }
    );


  }

  editUser(formValue: any) {
    this.UserObj = {
      "name": formValue.name,
      "email": formValue.email,
      "contact": formValue.contact,
      "id": formValue.id
    }
    this._http.put("http://localhost:3000/users/" + this.id,this.UserObj)
      .subscribe((response) => {

        this.isEdited = true;
        this.router.navigate(['/user-details'])
      })
  }
}