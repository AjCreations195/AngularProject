import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css'],
  providers: [CommonService]
})
export class UserDetailsComponent implements OnInit {

  // userData:any=[
  //   {name:"John",email:"john@gmail.com",contact:8866708473},
  //   {name:"Diya",email:"diya@gmail.com",contact:7036747466},
  //   {name:"Safa",email:"safa@gmail.com",contact:7366644664},
  //   {name:"Jack",email:"jack@gmail.com",contact:6464947283}
  // ];

  constructor(private commonService: CommonService, private _http: HttpClient) { }
  user: any = [];
   fetchdata() {
    this._http.get("http://localhost:3000/users").subscribe((response) => {
      this.user = response;
    })
  }
  deleteUser(id: number) {
    if (confirm("Are you Sure?")) {
      const url = '${"http://localhost:3000/users"}/{id}';
      this.commonService.deleteUser(id).subscribe(() => {
        this.fetchdata();
      })
    }
  }

  ngOnInit(): void {
    this.fetchdata()
  }


}




