import { CommonStore } from './common-store';

describe('CommonStore', () => {
  it('should create an instance', () => {
    expect(new CommonStore()).toBeTruthy();
  });
});
