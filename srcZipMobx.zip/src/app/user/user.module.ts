import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule, routingComponents } from './user-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { MobxAngularModule } from 'mobx-angular';
import { CommonService } from 'src/app/service/common.service'
import { CommonStore } from '../stores/common-store';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
      routingComponents
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    MobxAngularModule,
    RouterModule
  ],
  exports:[
    routingComponents
  ],
   providers: [CommonService,CommonStore]
})
export class UserModule { }
